﻿using MediaPlayerD.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace MediaPlayerD
{
    public partial class Form1 : Form
    {

      
        List<string> path = new List<string>();
        public Form1()
        {
            InitializeComponent();
            axWindowsMediaPlayer1.uiMode = "none";
            timer1.Enabled = true;
        }
        string[] paths, files;
        int Startindex = 0;
        string[] FileName, FilePath;
        Boolean playnext = false;

        bool _playing = false ;

        private void Form1_Load(object sender, EventArgs e)
        {
            Startindex = 0;
            playnext = false;
            StopPlayer();

        }

        public void StopPlayer()
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();

        }
        public void playfile(int playlistindex)
        {
            if(Playlist.Items.Count <=0)
            {
                return;
            }
            if(playlistindex <0)
            {
                return ;
            }
            axWindowsMediaPlayer1.settings.autoStart = true;    
            axWindowsMediaPlayer1.URL= FilePath[playlistindex];
            axWindowsMediaPlayer1.Ctlcontrols.next();
            axWindowsMediaPlayer1.Ctlcontrols.play();

        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {

        }

   
        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }


        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
             Startindex = 0;
            playnext = false;   
          
            openFileDialog1.Filter = "Video MKV (*.mkv)|*.mkv|Video MPEG (*.mpeg)|*.mpeg|" +
                " Video MP4 (*.mp4)|*.mp4|MP3 Audio File (*.mp3)|*.mp3|" +
                " Windows Media File (*.wma)|*.wma|WAV Audio File (*.wav)|*.wav";

            openFileDialog1.Multiselect = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FileName = openFileDialog1.SafeFileNames;
                FilePath = openFileDialog1.FileNames;

                for (int i = 0; i <= FileName.Length - 1; i++)
                {

                    Playlist.Items.Add(FileName[i]);
                }
                Startindex = 0;
                playfile(0);
            }
        }

        private void bunifuImageButton4_Click(object sender, EventArgs e)
        {
            Startindex = 0;
            playnext =false;
          
            openFileDialog1.Filter = "MP3 Audio File (*.mp3)|*.mp3|Windows Media File (*.wma)|*.wma|WAV Audio File (*.wav)|*.wav";
            openFileDialog1.Multiselect = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                FileName = openFileDialog1.SafeFileNames;
                FilePath = openFileDialog1.FileNames;
                for (int i = 0; i <= FileName.Length -1 ; i++)
                {
                    Playlist.Items.Add(FileName[i]);
                }
                Startindex = 0;
                playfile(0);
            }
        }

        private void Playlist_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            Startindex = Playlist.SelectedIndex;
            playfile(Startindex);
            label2.Text = Playlist.Text;
           
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton5_Click_1(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void bunifuImageButton7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void bunifuImageButton6_Click_1(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void bunifuImageButton12_Click(object sender, EventArgs e)
        {

        }

        private void bunifuHSlider1_Scroll(object sender, Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs e)
        {
            axWindowsMediaPlayer1.settings.volume = bunifuHSlider1.Value;
            label5.Text = bunifuHSlider1.Value.ToString();  
        }

        private void bunifuImageButton13_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuImageButton9_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.BringToFront();   
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {

            Playlist.BringToFront();

        }

        private void bunifuImageButton10_Click(object sender, EventArgs e)
        {
            if(Startindex > 0)
            {
                Startindex = Startindex - 1;
            }
            playfile(Startindex);
        }

        private void bunifuImageButton12_Click_1(object sender, EventArgs e)
        {
            StopPlayer();
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {
            // Windows Media Player 
            axWindowsMediaPlayer1.uiMode = "none";
        }

        private void Playlist_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void bunifuHSlider2_Scroll(object sender, Utilities.BunifuSlider.BunifuHScrollBar.ScrollEventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.currentPosition = bunifuHSlider2.Value;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int currentMediaPosition = (int)axWindowsMediaPlayer1.Ctlcontrols.currentPosition; // Dalam detik
            bunifuHSlider2.Value = currentMediaPosition;

            lbl_track_start.Text = axWindowsMediaPlayer1.Ctlcontrols.currentPositionString;
            lbl_track_end.Text = axWindowsMediaPlayer1.Ctlcontrols.currentPositionString;   
        }

        private void label2_Click(object sender, EventArgs e)
        {
         
        }
        
        private void Playlist_SelectedIndexChanged_2(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Playlist_SelectedIndexChanged_3(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton8_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.pause();
        }

        private void bunifuImageButton11_Click(object sender, EventArgs e)
        {
            if(Startindex==Playlist.Items.Count -1)
            {
                Startindex = Playlist.Items.Count - 1;
            }
            else if (Startindex < Playlist.Items.Count)
            {
                Startindex = Startindex + 1;

            }
            playfile(Startindex);
        }

        private void lbl_track_end_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void StartMediaPlayback()
        {
            axWindowsMediaPlayer1.Ctlcontrols.play();
            // Kode untuk memulai pemutaran media (misalnya, windowsMediaPlayer.Play())
            timer1.Start();
        }
        private void StopMediaPlayback()
        {
            axWindowsMediaPlayer1.Ctlcontrols.pause();
            // Kode untuk menghentikan pemutaran media (misalnya, windowsMediaPlayer.Stop())
            timer1.Stop();
        }
    }
}
